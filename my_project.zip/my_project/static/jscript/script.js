const btn = document.getElementById('my-btn') ;

const msg_box = document.getElementById('msg-box');

const body = document.body;

const theme_btn = document.getElementById('theme-toggle');

const product = document.getElementsByClassName('package');



console.log(body.getAttribute('data-bs-theme'));


theme_btn.addEventListener('click', toggleTheme);


function toggleTheme(){

    if (body.getAttribute('data-bs-theme') == 'dark'){

        body.setAttribute('data-bs-theme', 'light');

        theme_btn.innerText = 'Theme: Light'

        product.setAttribute('color','dark');

    } else{

        body.setAttribute('data-bs-theme', 'dark');

        theme_btn.innerText = 'Theme: Dark'


    }

}

$(document).ready(function() {
    $('#submit-btn').on('click', function(e) {
        e.preventDefault();  // Prevent the default form submission

        // Collect form data
        var formData = {
            username: $('#username').val(),
            email: $('#email').val(),
            password: $('#password').val(),
            phone: $('#phone').val(),
            csrfmiddlewaretoken : $('input[name="csrfmiddlewaretoken"]').val()
        };
        // Perform the AJAX POST request to Django view
        $.ajax({
            type: 'POST',
            url: '{% url "handle_personal_info" %}',  // URL for your Django view
            data: formData,
            success: function(response) {
                if (response.status === 'success') {
                    alert('Information submitted successfully!');
                    $('#staticBackdrop').modal('hide');  // Close the modal after successful submission
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
                alert('An error occurred while submitting the form.');
            }
        });
    });
});
