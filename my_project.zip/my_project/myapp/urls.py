from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('navbar/', views.navbar, name='navbar'),
    path('handle_personal_info/', views.handle_personal_info, name='handle_personal_info'),
    path('about/', views.about, name='about'),
    path('checkout/', views.checkout, name='checkout'),
    path('feedback/', views.feedback, name='feedback'),
    path('products/', views.products, name='products'),
    path('rushCommunity/', views.rushCommunity, name='rushCommunity'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
