from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def handle_personal_info(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone = request.POST.get('phone')

        # Process data (save to DB, etc.)

        return JsonResponse({'status': 'success', 'message': 'Information saved successfully.'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'})


def home(request):
    return render(request, 'home.html')
def navbar(request):
    return render(request, 'navbar.html')
def handle_personal_info(request):
    return render(request, 'handle_personal_info.html')
def about(request):
    return render(request, 'aboutUs.html')
def checkout(request):
    return render(request, 'checkout.html')
def feedback(request):
    return render(request, 'feedback.html')
def products(request):
    return render(request, 'products.html')
def rushCommunity(request):
    return render(request, 'rushCommunity.html')

# Create your views here.
